const express = require("express");
const router = express.Router();

const {
  getNotifications,
  sendNotification,
  deleteNotification,
} = require("../controllers/notificationController");

router.get("/", getNotifications);
router.post("/send", sendNotification);
router.delete("/:id", deleteNotification);

module.exports = router;
