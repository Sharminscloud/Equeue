const Pusher = require("pusher");

let pusher = null;

if (
  process.env.PUSHER_APP_ID &&
  process.env.PUSHER_KEY &&
  process.env.PUSHER_SECRET &&
  process.env.PUSHER_CLUSTER
) {
  pusher = new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: process.env.PUSHER_CLUSTER,
    useTLS: true,
  });
}

async function triggerQueueUpdate(data) {
  if (!pusher) {
    console.log("Pusher not configured. Queue update simulated:", data);
    return;
  }

  await pusher.trigger("equeue-channel", "queue-updated", data);
}

module.exports = {
  triggerQueueUpdate,
};
