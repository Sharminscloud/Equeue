function startReminderScheduler() {
  console.log(
    "Reminder scheduler is ready. Manual email reminder API is used in this version.",
  );
}

module.exports = {
  startReminderScheduler,
};
