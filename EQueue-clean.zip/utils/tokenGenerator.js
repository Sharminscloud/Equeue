function formatTokenNumber(number) {
  return String(number).padStart(3, "0");
}

function generateTokenCode(isPriority, tokenNumber, preferredDate) {
  const prefix = isPriority ? "P" : "N";
  const cleanDate = preferredDate.replaceAll("-", "");
  return `${prefix}-${cleanDate}-${formatTokenNumber(tokenNumber)}`;
}

module.exports = {
  formatTokenNumber,
  generateTokenCode,
};
