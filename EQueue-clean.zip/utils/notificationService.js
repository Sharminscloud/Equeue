const nodemailer = require("nodemailer");

async function sendEmailNotification({ to, subject, message }) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.log("Email simulated because EMAIL_USER or EMAIL_PASS is missing");
    console.log("To:", to);
    console.log("Subject:", subject);
    console.log("Message:", message);

    return {
      status: "Simulated",
      error: "",
    };
  }

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject,
      text: message,
    });

    return {
      status: "Sent",
      error: "",
    };
  } catch (error) {
    return {
      status: "Failed",
      error: error.message,
    };
  }
}

module.exports = {
  sendEmailNotification,
};
