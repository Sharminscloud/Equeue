const Notification = require("../models/Notification");
const { sendEmailNotification } = require("../utils/notificationService");

async function getNotifications(req, res) {
  try {
    const notifications = await Notification.find().sort({ createdAt: -1 });
    res.status(200).json(notifications);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch notifications",
      error: error.message,
    });
  }
}

async function sendNotification(req, res) {
  try {
    const { email, type, subject, message } = req.body;

    if (!email || !subject || !message) {
      return res.status(400).json({
        message: "email, subject, and message are required",
      });
    }

    const result = await sendEmailNotification({
      to: email,
      subject,
      message,
    });

    const notification = await Notification.create({
      email,
      type: type || "General",
      subject,
      message,
      status: result.status,
      error: result.error,
    });

    res.status(201).json({
      message: "Notification processed",
      notification,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to process notification",
      error: error.message,
    });
  }
}
async function deleteNotification(req, res) {
  try {
    const notification = await Notification.findByIdAndDelete(req.params.id);

    if (!notification) {
      return res.status(404).json({
        message: "Notification not found",
      });
    }

    res.status(200).json({
      message: "Notification deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to delete notification",
      error: error.message,
    });
  }
}
module.exports = {
  getNotifications,
  sendNotification,
  deleteNotification,
};
