const Token = require("../models/Token");
const Appointment = require("../models/Appointment");

async function getActivityByEmail(req, res) {
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({
        message: "email query is required",
      });
    }

    const tokens = await Token.find({
      email: email.toLowerCase(),
    })
      .populate("branch")
      .populate("service")
      .sort({ createdAt: -1 });

    const appointments = await Appointment.find({
      email: email.toLowerCase(),
    })
      .populate("branch")
      .populate("service")
      .sort({ createdAt: -1 });

    res.status(200).json({
      email,
      tokens,
      appointments,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch activity history",
      error: error.message,
    });
  }
}

module.exports = {
  getActivityByEmail,
};
