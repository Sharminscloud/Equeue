const mongoose = require("mongoose");

const tokenSchema = new mongoose.Schema(
  {
    branch: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Branch",
      required: true,
    },
    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Service",
      required: true,
    },
    preferredDate: {
      type: String,
      required: [true, "Preferred date is required"],
    },
    name: {
      type: String,
      required: [true, "Citizen name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Citizen email is required"],
      trim: true,
      lowercase: true,
    },
    phone: {
      type: String,
      required: [true, "Phone number is required"],
      trim: true,
    },
    isPriority: {
      type: Boolean,
      default: false,
    },
    tokenNumber: {
      type: Number,
      required: true,
    },
    tokenCode: {
      type: String,
      required: true,
      unique: true,
    },
    queuePosition: {
      type: Number,
      required: true,
    },
    estimatedWaitingTime: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      enum: ["Waiting", "Serving", "Completed", "Cancelled"],
      default: "Waiting",
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Token", tokenSchema);
