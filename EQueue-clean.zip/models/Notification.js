const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    type: {
      type: String,
      enum: ["Queue Alert", "Appointment Reminder", "General"],
      default: "General",
    },
    subject: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ["Sent", "Failed", "Simulated"],
      default: "Simulated",
    },
    error: {
      type: String,
      default: "",
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Notification", notificationSchema);
